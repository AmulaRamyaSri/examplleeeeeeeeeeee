package com.homemate.service_provider_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProviderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
