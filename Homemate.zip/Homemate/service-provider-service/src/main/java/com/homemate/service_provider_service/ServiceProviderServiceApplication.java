package com.homemate.service_provider_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceProviderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceProviderServiceApplication.class, args);
	}

}
